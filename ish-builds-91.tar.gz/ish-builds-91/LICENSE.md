iSH is licensed under the [GPLv3][]. The additional terms in LICENSE.IOS also apply.

Contributions made after commit c4f8d4be2df78cea70d7699262411ab274ef9b01 are
additionally licensed under the [GPLv2][]. This is intended to allow linking
with GPLv2 licensed projects such as Linux and QEMU.

The following authors have agreed to relicense their past contributions under GPLv2:
- Theodore Dubois <tblodt@icloud.com>
- Saagar Jha <saagar@saagarjha.com>
- Christoffer Tønnessen <christoffertonnessen@icloud.com> <christoffer.tonnessen@gmail.com>
- Philipp Wallisch <philipp.wallisch@inode.at>
- Ed Luff <beartechtalks@gmail.com>
- David Southgate <d@davidsouthgate.co.uk>

[GPLv3]: https://www.gnu.org/licenses/gpl-3.0.html
[GPLv2]: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
