//
//  FontPickerViewController.h
//  iSH
//
//  Created by Theodore Dubois on 10/26/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

NS_CLASS_DEPRECATED_IOS(10_0, 12_0, "UIFontPickerViewController is better")
@interface FontPickerViewController : UITableViewController

@end

NS_ASSUME_NONNULL_END
