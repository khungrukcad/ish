#ifndef KERNEL_RANDOM_H
#define KERNEL_RANDOM_H

#include <stdlib.h>

int get_random(char *buf, size_t len);

#endif
