//
//  APKFilesystem.h
//  iSH
//
//  Created by Theodore Dubois on 11/27/20.
//

extern const struct fs_ops apkfs;

extern NSString *const APKDownloadStartedNotification;
extern NSString *const APKDownloadFinishedNotification;
